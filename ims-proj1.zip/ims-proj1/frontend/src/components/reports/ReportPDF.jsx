import React from 'react';

// This is a placeholder component since we're having issues with @react-pdf/renderer
const ReportPDF = ({ content }) => {
    return (
        <div>
            <p>PDF generation is not available in this version.</p>
        </div>
    );
};

export default ReportPDF; 